package com.Ecommerce.EcommerceWebsite;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class EcommerceWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
