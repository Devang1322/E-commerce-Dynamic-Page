package com.Ecommerce.EcommerceWebsite;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class ClothingService {
    @Autowired
    private ClothingRepository clothingRepository;

    public List<ClothingItem> searchItems(String query) {
        return clothingRepository.findByNameContainingIgnoreCase(query);
    }
}
